#define Hundred() (10*10)
class Test2{
    public static void main(String[] a){
	System.out.println(Hundred());
    }
}