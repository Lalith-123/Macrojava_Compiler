#define TOPRINT(a,b) (a * b)
class Test26{
    public static void main(String[] a){
	System.out.println(TOPRINT( 10, 10));
    }
}
