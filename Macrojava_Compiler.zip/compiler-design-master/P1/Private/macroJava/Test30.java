#define TOPRINT(a) ( !(a))
class Test30{
    public static void main(String[] a){
	System.out.println(TOPRINT( (true)));
    }
}
