#define TOPRINT(a) ( !(a))
class Test31{
    public static void main(String[] a){
	System.out.println(TOPRINT( (false)));
    }
}
